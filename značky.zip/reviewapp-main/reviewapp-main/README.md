# reviewapp

## Aplikaci najdete [zde](https://mariand.eu.pythonanywhere.com/)

### pro otestování přidávání recenzí můžete použít účet s následujícími přihlašovacími údaji: 

#### Přihlašovací údaje:
- Uživatelské jméno: test
- Heslo: testovaciucet
